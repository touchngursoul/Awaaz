export const officialDataSources = [
  {
    source: "NCRB Crime in India",
    coverage: "State, city and many district-level crime tables",
    useFor: "Crimes against women, children, cybercrime, kidnapping, trafficking and related safety indicators",
    trust: "Official",
    status: "Priority source for Version 1",
  },
  {
    source: "NCRB Accidental Deaths & Suicides in India",
    coverage: "State, UT and selected demographic suicide tables",
    useFor: "Student suicide, family issues, illness, unemployment and other suicide-cause baselines",
    trust: "Official",
    status: "Priority source for Version 1",
  },
  {
    source: "NCW / NCPCR / UGC / SHe-Box / Cyber Crime Portal",
    coverage: "Institutional and category-specific complaint systems",
    useFor: "Women safety, child protection, ragging, workplace harassment and cyber harassment references",
    trust: "Official / statutory",
    status: "Use as corroborating source",
  },
  {
    source: "Media-reported case bank",
    coverage: "Incident-level examples with date, district, category and source link",
    useFor: "Recent examples, pattern discovery and district risk narrative",
    trust: "Needs verification",
    status: "Manual validation required before public use",
  },
];

export const riskSignals = [
  { signal: "Repeated bullying or exclusion", category: "Bullying", level: "L2", route: "Institution welfare team + counselor" },
  { signal: "Threats, blackmail or stalking", category: "Cyber / physical threat", level: "L3", route: "Cyber guidance + district safety review" },
  { signal: "Bad touch or sexual harassment", category: "Abuse / harassment", level: "L3", route: "Authorized protection system + counselor" },
  { signal: "Self-harm words or immediate danger", category: "Mental distress", level: "L4", route: "Crisis helpline + urgent safety protocol" },
  { signal: "Institutional negligence pattern", category: "Governance risk", level: "L2-L3", route: "District committee trend review" },
];

export const evidenceRules = [
  "No report should be published publicly.",
  "Awaaz should never declare guilt or legal liability.",
  "Data shown on public pages must separate official records, media compilations and estimates.",
  "Unreported cases must be shown only as research-based estimate ranges, never as exact numbers.",
  "Any production build must use consent, encryption, access control, audit logs and data minimization.",
];

export const districtPilotMetrics = [
  "Reports received by category",
  "High-risk signals detected",
  "Average first-review time",
  "Support routes suggested",
  "Repeat category patterns by institution type",
  "False / duplicate reports flagged",
  "Monthly anonymous district trend score",
];
