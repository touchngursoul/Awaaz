# Awaaz Setu Improvement Notes

This version improves the prototype from a simple anonymous reporting demo into a stronger preventive safety intelligence concept.

## What was improved

1. Added a reusable `awaazIntelligence.ts` data layer for:
   - official source register
   - early warning risk signals
   - public data rules
   - district pilot KPIs

2. Improved the Awareness page:
   - added Data Source Register
   - added Public Data Rules
   - added Early Warning Risk Signals table
   - made the disclaimer stronger and safer for government/investor presentation

3. Improved the Home page positioning:
   - clearer 3-layer model: Safe Intake, Support Routing, Safety Intelligence
   - added district pilot metrics section
   - stronger government/CSR pitch framing

4. Improved the Admin dashboard:
   - added Admin Governance Checklist
   - added District Pilot KPI panel
   - reinforces that the portal must not publish reports, declare guilt, or show fake exact unreported numbers

5. Improved backend awareness disclaimer:
   - clarified that demo numbers are placeholders until replaced by NCRB/ADSI and verified case-bank entries

## Important production requirements

Before public launch, the following are required:

- Real database instead of local storage/mock data
- Authentication and role-based access control
- Encryption at rest and in transit
- Audit logs with tamper-resistant storage
- Legal review for privacy and evidence handling
- Helpline verification
- Consent and data-retention policy
- Official data ingestion pipeline from NCRB/ADSI and other verified sources
- Manual moderation SOP for L3/L4 cases
- Misuse-prevention and false-report handling policy

## Recommended next phase

Build Version 2 with:

- real database schema
- source register upload/import module
- incident case-bank management
- district risk index calculation
- admin role permissions
- institutional login
- counselor/NGO referral workflow
- downloadable monthly district report
